import view
import controller

controller.repeater(view.root)
view.root.mainloop()
